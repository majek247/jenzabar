function WingMark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M32 8C24 -2 6 0 2 12c-3 9 4 18 14 18 6 0 11-3 14-8"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      <path
        d="M32 8c8-10 26-8 30 4 3 9-4 18-14 18-6 0-11-3-14-8"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      <path d="M32 8v34" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-ink/10 bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <div className="flex items-center gap-2.5 text-ink">
          <WingMark className="h-6 w-8 text-wing" />
          <span className="font-display text-lg tracking-tight">Jenzabar</span>
        </div>
        <nav className="hidden items-center gap-8 font-body text-sm text-ink/70 md:flex">
          <a href="#platform" className="hover:text-ink">Jenzabar One</a>
          <a href="#unify" className="hover:text-ink">Solutions</a>
          <a href="#services" className="hover:text-ink">Services</a>
          <a href="#proof" className="hover:text-ink">Campuses</a>
        </nav>
        <a
          href="#demo"
          className="rounded-full bg-ink px-5 py-2.5 font-body text-sm font-medium text-paper transition hover:bg-harbor"
        >
          Request a demo
        </a>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-ink/10">
      <div className="mx-auto grid max-w-6xl gap-12 px-6 pb-20 pt-16 md:grid-cols-[1.2fr_1fr] md:pt-24">
        <div>
          <p className="font-body text-sm font-medium text-wing">
            Higher education, exclusively — since 1998
          </p>
          <h1 className="mt-5 max-w-xl font-display text-[2.75rem] leading-[1.08] text-ink md:text-6xl">
            One partner for every office on campus.
          </h1>
          <p className="mt-6 max-w-md font-body text-lg leading-relaxed text-ink/70">
            Jenzabar unifies student records, finance, advancement, and enrollment
            under a single system — so your staff spend less time reconciling data
            and more time with students.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a
              href="#demo"
              className="rounded-full bg-wing px-7 py-3.5 font-body text-sm font-semibold text-paper transition hover:bg-harbor"
            >
              See Jenzabar One in action
            </a>
            <a
              href="#proof"
              className="font-body text-sm font-medium text-ink underline decoration-ink/30 underline-offset-4 hover:decoration-ink"
            >
              Why 1,400+ campuses stay
            </a>
          </div>
        </div>

        <div className="relative flex items-center justify-center">
          <svg viewBox="0 0 320 320" className="w-full max-w-sm text-wing">
            <circle cx="160" cy="160" r="118" fill="none" stroke="currentColor" strokeOpacity="0.15" strokeWidth="1.5" />
            <path
              d="M160 60C120 20 40 30 24 90c-14 52 26 96 76 96 32 0 58-16 72-42"
              fill="none"
              stroke="currentColor"
              strokeWidth="3"
              strokeLinecap="round"
            />
            <path
              d="M160 60c40-40 120-30 136 30 14 52-26 96-76 96-32 0-58-16-72-42"
              fill="none"
              stroke="currentColor"
              strokeWidth="3"
              strokeLinecap="round"
              className="text-dawn"
              stroke-opacity="1"
            />
            <path d="M160 60v146" stroke="currentColor" strokeOpacity="0.4" strokeWidth="3" strokeLinecap="round" />
          </svg>
        </div>
      </div>
    </section>
  );
}

function StatBand() {
  const stats = [
    ["1,400+", "campuses run on Jenzabar"],
    ["#1", "SIS chosen most over the last decade"],
    ["30+", "years serving higher ed exclusively"],
  ];
  return (
    <section className="border-b border-ink/10 bg-ink text-paper">
      <div className="mx-auto grid max-w-6xl grid-cols-1 divide-y divide-paper/15 px-6 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
        {stats.map(([n, l]) => (
          <div key={l} className="py-10 text-center sm:px-8">
            <div className="font-display text-4xl">{n}</div>
            <div className="mt-2 font-body text-sm text-paper/60">{l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Unify() {
  const depts = [
    { label: "Admissions", angle: -70 },
    { label: "Registrar", angle: -25 },
    { label: "Finance", angle: 20 },
    { label: "Advancement", angle: 65 },
    { label: "Financial Aid", angle: 110 },
    { label: "Student Success", angle: 155 },
  ];
  return (
    <section id="unify" className="border-b border-ink/10 bg-cloud">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <div className="grid gap-14 md:grid-cols-2 md:items-center">
          <div>
            <p className="font-body text-sm font-medium text-wing">One system, every department</p>
            <h2 className="mt-4 font-display text-3xl leading-tight text-ink md:text-4xl">
              Stop stitching software together.
            </h2>
            <p className="mt-5 max-w-md font-body leading-relaxed text-ink/70">
              Most campuses run six or more disconnected tools that don't talk to
              each other. Jenzabar One replaces that patchwork with a single
              record for every student, from first inquiry to alumni giving.
            </p>
            <dl className="mt-8 space-y-5 font-body">
              <div className="flex gap-4">
                <dt className="w-28 shrink-0 font-medium text-ink">One record</dt>
                <dd className="text-ink/70">A student's data updates everywhere at once — no re-entry, no drift.</dd>
              </div>
              <div className="flex gap-4">
                <dt className="w-28 shrink-0 font-medium text-ink">One vendor</dt>
                <dd className="text-ink/70">A single support relationship instead of six separate contracts.</dd>
              </div>
              <div className="flex gap-4">
                <dt className="w-28 shrink-0 font-medium text-ink">One roadmap</dt>
                <dd className="text-ink/70">Updates ship together, so integrations never fall out of sync.</dd>
              </div>
            </dl>
          </div>

          <div className="relative mx-auto aspect-square w-full max-w-md">
            <svg viewBox="0 0 400 400" className="h-full w-full">
              {depts.map((d) => {
                const rad = (d.angle * Math.PI) / 180;
                const r = 148;
                const x = 200 + r * Math.cos(rad);
                const y = 200 + r * Math.sin(rad);
                return (
                  <line
                    key={d.label}
                    x1="200"
                    y1="200"
                    x2={x}
                    y2={y}
                    stroke="#1C8FB0"
                    strokeOpacity="0.35"
                    strokeWidth="1.5"
                  />
                );
              })}
              <circle cx="200" cy="200" r="46" fill="#0C2233" />
              <text x="200" y="196" textAnchor="middle" fill="#FAF9F5" className="font-display" fontSize="15">
                Jenzabar
              </text>
              <text x="200" y="213" textAnchor="middle" fill="#FAF9F5" className="font-display" fontSize="15">
                One
              </text>
              {depts.map((d) => {
                const rad = (d.angle * Math.PI) / 180;
                const r = 148;
                const x = 200 + r * Math.cos(rad);
                const y = 200 + r * Math.sin(rad);
                return (
                  <g key={d.label + "n"}>
                    <circle cx={x} cy={y} r="4" fill="#E7A33E" />
                    <text
                      x={x}
                      y={y + (d.angle > -90 && d.angle < 90 ? -14 : 20)}
                      textAnchor="middle"
                      fill="#0C2233"
                      className="font-body"
                      fontSize="12.5"
                    >
                      {d.label}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}

function Proof() {
  return (
    <section id="proof" className="border-b border-ink/10">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <p className="font-body text-sm font-medium text-wing">In their words</p>
        <blockquote className="mt-5 max-w-3xl font-display text-2xl leading-snug text-ink md:text-3xl">
          "Our office of Student Success built a system of early intervention using
          Jenzabar Retention — our engagement rate is up, and retention has stayed
          above 90%."
        </blockquote>
        <p className="mt-5 font-body text-sm text-ink/60">
          Alaina Mount — Assistant Dean of Student Affairs, Parker University
        </p>

        <div className="mt-16 grid gap-8 border-t border-ink/10 pt-12 sm:grid-cols-3">
          {[
            ["Charleston Southern University", "Went fully paperless across admissions and the registrar."],
            ["Gordon College", "Cut applicant communication time from days to minutes."],
            ["Grove City College", "Faster turnaround on product feedback and fixes."],
          ].map(([name, blurb]) => (
            <div key={name}>
              <div className="font-display text-base text-ink">{name}</div>
              <p className="mt-2 font-body text-sm leading-relaxed text-ink/60">{blurb}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section id="demo" className="bg-harbor text-paper">
      <div className="mx-auto max-w-6xl px-6 py-20 text-center">
        <h2 className="font-display text-3xl leading-tight md:text-4xl">
          See what one system looks like on your campus.
        </h2>
        <p className="mx-auto mt-4 max-w-md font-body text-paper/70">
          A 30-minute walkthrough, scoped to the departments you care about most.
        </p>
        <a
          href="#"
          className="mt-8 inline-block rounded-full bg-dawn px-8 py-3.5 font-body text-sm font-semibold text-ink transition hover:brightness-95"
        >
          Schedule a demo
        </a>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-ink text-paper/70">
      <div className="mx-auto max-w-6xl px-6 py-14">
        <div className="flex flex-col gap-8 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-center gap-2.5 text-paper">
            <WingMark className="h-5 w-7" />
            <span className="font-display text-base">Jenzabar</span>
          </div>
          <div className="grid grid-cols-2 gap-x-12 gap-y-2 font-body text-sm sm:grid-cols-3">
            <a href="#" className="hover:text-paper">Jenzabar One</a>
            <a href="#" className="hover:text-paper">Solutions</a>
            <a href="#" className="hover:text-paper">Services</a>
            <a href="#" className="hover:text-paper">About</a>
            <a href="#" className="hover:text-paper">Careers</a>
            <a href="#" className="hover:text-paper">Contact</a>
          </div>
        </div>
        <div className="mt-10 border-t border-paper/10 pt-6 font-body text-xs text-paper/40">
          111 Huntington Avenue, Suite 530, Boston, MA 02199 · © Jenzabar, Inc.
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="font-body text-ink">
      <Header />
      <Hero />
      <StatBand />
      <Unify />
      <Proof />
      <CTA />
      <Footer />
    </div>
  );
}
